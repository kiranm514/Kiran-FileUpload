﻿using System.Collections.Generic;

namespace Kiran.FileUpload.Models.Home
{
    

    public class ExpirationFilesViewModel
    {
        public Dictionary<string,string> Filesexpiry { get; set; } 
            = new Dictionary<string, string>();
    }
}
